            </div>
	</div>
	

</div>
        </div><!-- close .*-inner (main-content) -->
    </div><!-- close .container -->
</div><!-- close .main-content -->

<footer id="colophon" class="site-footer" role="contentinfo">
       <div id="footer-info">
        <div class="container">
            <div class="site-info">
				Designed by  <a href="https://www.linkedin.com/in/akhil-tom-4162991a3/" title="">Akhil Tom</a>
            </div><!-- close .site-info -->
        </div>
    </div>
</footer><!-- close #colophon -->
<script>var baseurl = "<?php echo site_url(); ?>";</script>
<script type="text/javascript" src="<?php print HTTP_JS_PATH; ?>jquery.min.js"></script>
<script src="<?php echo HTTP_JS_PATH; ?>jquery-ui.js"></script>
<script type="text/javascript" src="<?php print HTTP_JS_PATH; ?>/bootstrap/bootstrap.min.js"></script>
<script src="<?php print HTTP_JS_PATH; ?>jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?php print HTTP_JS_PATH; ?>/common.js"></script>		
</body>
</html>
